"""
Orgni Docs — Integration Tests
Run from orgni-docs/: python tests/test_pipeline.py
"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from extraction.extractor import extract
from validation.engine import validate
from integrity.trust_scorer import score


CLEAN_INVOICE_PAGES = [{
    "page": 1,
    "text": """ABC Logistics (Pty) Ltd
VAT Reg No: 4560123789
Invoice No: INV-2024-0081
Invoice Date: 15/03/2024
Due Date: 15/04/2024
Bill To:
XYZ Manufacturing CC
Subtotal:    R13,043.48
VAT (15%):   R1,956.52
Total Due:   R15,000.00"""
}]

CORRUPTED_PAGES = [{
    "page": 1,
    "text": """ABC Logistics (Pty) Ltd
Invoice No: INV-2024-0081
Subtotal:  R13,043.48
VAT (15%): R1,956.52
Total Due: R1,500.00"""
}]


def test_clean_pipeline():
    print("\n=== Clean Invoice — Full Pipeline ===")
    ext = extract("doc_clean", CLEAN_INVOICE_PAGES)
    val = validate("doc_clean", ext["extracted_fields"])
    trust = score("doc_clean", extraction_data=ext, validation_data=val)

    print(f"Completeness: {ext['completeness_score']}, Validation passed: {val['passed']}, Trust: {trust['trust_score']}, Verdict: {trust['verdict']}")

    assert val["passed"]
    assert ext["extracted_fields"].get("date") == "2024-03-15"
    assert ext["extracted_fields"].get("invoice_total") == 15000.0
    print("✓ Clean pipeline passed")


def test_corrupted_pipeline():
    print("\n=== Corrupted Invoice — Expect Flagged ===")
    ext = extract("doc_corrupt", CORRUPTED_PAGES)
    val = validate("doc_corrupt", ext["extracted_fields"])
    trust = score("doc_corrupt", extraction_data=ext, validation_data=val)

    print(f"Validation passed: {val['passed']}, Verdict: {trust['verdict']}")
    assert not val["passed"]
    assert "math_subtotal_plus_vat" in [i["rule"] for i in val["issues"]]
    assert trust["verdict"] in ("REVIEW", "BLOCKED")
    print("✓ Corrupted pipeline correctly flagged")


if __name__ == "__main__":
    test_clean_pipeline()
    test_corrupted_pipeline()
    print("\n✓ All integration tests passed")

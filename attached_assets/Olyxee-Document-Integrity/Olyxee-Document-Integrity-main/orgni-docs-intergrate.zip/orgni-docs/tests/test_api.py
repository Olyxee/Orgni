"""
Orgni Docs — FastAPI Endpoint Tests
Run from orgni-docs/: python -m pytest tests/test_api.py -v
"""
import sys, os, io
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)
SAMPLE_DIR = os.path.join(os.path.dirname(__file__), "..", "sample_files")


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["service"] == "orgni-docs"


def test_run_with_real_invoice_image():
    path = os.path.join(SAMPLE_DIR, "sample_invoice.png")
    with open(path, "rb") as f:
        response = client.post("/run", files={"file": ("sample_invoice.png", f, "image/png")})
    assert response.status_code == 200
    body = response.json()
    assert body["verdict"] in ("APPROVED", "REVIEW", "BLOCKED")
    assert "field_sources" in body["stage_outputs"]["extraction"]


def test_run_with_corrupted_invoice_math():
    path = os.path.join(SAMPLE_DIR, "sample_invoice_corrupted.png")
    with open(path, "rb") as f:
        response = client.post("/run", files={"file": ("sample_invoice_corrupted.png", f, "image/png")})
    assert response.status_code == 200
    body = response.json()
    assert body["verdict"] in ("REVIEW", "BLOCKED")
    assert "math_subtotal_plus_vat" in [i["rule"] for i in body["stage_outputs"]["validation"]["issues"]]


def test_run_with_unsupported_file_type():
    fake_file = io.BytesIO(b"not a real document")
    response = client.post("/run", files={"file": ("notes.txt", fake_file, "text/plain")})
    assert response.status_code == 415


def test_run_with_oversized_file():
    oversized = io.BytesIO(b"0" * (21 * 1024 * 1024))
    response = client.post("/run", files={"file": ("huge.pdf", oversized, "application/pdf")})
    assert response.status_code == 413


def test_run_with_empty_file():
    empty = io.BytesIO(b"")
    response = client.post("/run", files={"file": ("empty.pdf", empty, "application/pdf")})
    assert response.status_code == 400


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])

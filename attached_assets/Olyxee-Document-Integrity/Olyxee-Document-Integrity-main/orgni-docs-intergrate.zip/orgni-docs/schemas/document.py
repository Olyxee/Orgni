"""
Orgni Docs Schemas — shared data models used across the pipeline.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any


DOCUMENT_FIELDS = [
    "invoice_number", "date", "due_date",
    "supplier", "client", "vat_number",
    "invoice_total", "vat", "subtotal",
]

CRITICAL_FIELDS = {"invoice_total", "vat", "subtotal"}
RECOMMENDED_FIELDS = {"invoice_number", "date", "supplier", "client"}
FIELD_SOURCES = {"regex", "llm", "not_found"}


@dataclass
class OCRPage:
    page: int
    text: str
    char_count: int
    ocr_confidence: float | None
    confidence_detail: dict | None
    fallback_used: bool
    parser: str
    processing_ms: float
    checksum: str

    def to_dict(self) -> dict:
        return self.__dict__.copy()


@dataclass
class ExtractionResult:
    document_id: str
    extracted_fields: dict[str, Any]
    field_sources: dict[str, str]
    field_confidence: dict[str, float]
    missing_fields: list[str]
    critical_missing: list[str]
    completeness_score: float
    raw_text_length: int
    llm_error: str | None = None

    def to_dict(self) -> dict:
        return self.__dict__.copy()


@dataclass
class ValidationIssue:
    rule: str
    severity: str
    message: str
    field: str | None = None
    expected: Any = None
    actual: Any = None

    def to_dict(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if v is not None}

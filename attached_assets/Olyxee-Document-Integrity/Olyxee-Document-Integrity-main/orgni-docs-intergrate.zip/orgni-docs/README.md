# Orgni Docs

Document understanding, integrity, validation, and extraction service.
Lives as a standalone folder in the Orgni monorepo, separate from `/engine` (Node.js).

## Run locally

```bash
cd orgni-docs
pip install -r requirements.txt
export TESSERACT_CMD=/usr/bin/tesseract   # or Windows path
export ANTHROPIC_API_KEY=your_key          # optional, regex works without it
uvicorn main:app --reload
```

API docs: http://127.0.0.1:8000/docs

## Test

```bash
python tests/test_pipeline.py
python -m pytest tests/test_api.py -v
```

## Endpoints

| Endpoint | Method |
|---|---|
| `/run` | POST — upload a document, get back verdict + trust score |
| `/health` | GET |

## Structure

```
orgni-docs/
├── ocr/          OCR extraction
├── extraction/   Structured field extraction
├── schemas/      Shared data models
├── validation/   Constraint checks
├── integrity/    Trust scoring
├── pipeline/     Orchestrator
├── tests/
├── sample_files/
├── main.py
└── config.py
```
